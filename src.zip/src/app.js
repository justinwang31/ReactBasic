import WelcomeMessage from "./demos/welcome-message";
import SpeakButton from "./demos/speak-button";
import ChatMessage from "./demos/chat-message";
import Alert from "./demos/alert-button";
import SocialPost from "./demos/social-post";
function App()
{
  return(<main>
    <h1>My first react app</h1>
    
    <h2>Welcome</h2>
    <WelcomeMessage name = "Justin" greeting = "Howdy"/>

    <h2>Buttons</h2>
    <SpeakButton message="Hello There!" rate={1} pitch = {1} />
    <SpeakButton message="Speed speed speed" rate={3} pitch = {2} /> 
    <h2>Chat</h2>
    <ChatMessage message="Yo, how's react?" userName= "EndW" date= "02/15/21" />
    <ChatMessage message="Its going well" userName= "SHB" date= "02/15/21" />

    <h2>Alert Button</h2>
    <Alert buttonText = "Hello!" alertMessage= "Goodbye"></Alert>

    <h2>Social Media</h2>
    <SocialPost content= "Hello. Is anyone out there?" userName ="-JSNewbie" numLikes= {10} numThumbsUP= {0} numSparkles= {0} ></SocialPost>
    <SocialPost content= "I'm a social media master and everything I post is gold." userName ="-ReactStar21" numLikes= {1} numThumbsUP= {2} numSparkles= {11} ></SocialPost>
   </main>);
}



export default App;