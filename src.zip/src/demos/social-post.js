import "./chat-message.css";

function SocialPost ({content, userName, numLikes = 0, numThumbsUP = 0, numSparkles = 0})
{
    return(
        <div className="chat-message">
        <span>{content}</span>
        <span className="chat-message__name">{userName}</span>
        <span className="chat-message__date">💙{numLikes}👍{numThumbsUP}✨{numSparkles}</span>
        </div>
    )
}

export default SocialPost;