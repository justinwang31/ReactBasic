



function Alert({buttonText = "hello", alertMessage = "Bye"})
{
    const action = ()  => 
    {
        alert(buttonText);
        alert(alertMessage);
    }

    return <button onClick={action}>Alert</button>;

}

export default Alert;